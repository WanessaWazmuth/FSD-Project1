package com.dev.store.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.Administrator;
import com.dev.store.repositories.AdministratorRepositories;

@Controller
public class AdministratorController {
	
	@Autowired
	private AdministratorRepositories administratorRepositories;
	
	@GetMapping("/api/admin/administrator/toregister")
	public ModelAndView toregister(Administrator administrator) {
		ModelAndView mv =  new ModelAndView("api/admin/administrator/register");
		mv.addObject("administrator",administrator);
		return mv;
	}
	
	@GetMapping("/api/admin/administrator/tolist")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/admin/administrator/list");
		mv.addObject("listAdministrator", administratorRepositories.findAll());
		return mv;
	}
	
	@GetMapping("/api/admin/administrator/edit/{id}")
	public ModelAndView editar(@PathVariable("id") Long id) {
		Optional<Administrator> administrator = administratorRepositories.findById(id);
		return toregister(administrator.get());
	}
	
	@GetMapping("/api/admin/administrator/remove/{id}")
	public ModelAndView remove(@PathVariable("id") Long id) {
		Optional<Administrator> administrator = administratorRepositories.findById(id);
		administratorRepositories.delete(administrator.get());
		return list();
	}
	
	@PostMapping("/api/admin/administrator/save")
	public ModelAndView save(@Valid Administrator administrator, BindingResult result) {
		
		if(result.hasErrors()) {
			return toregister(administrator);
		}
		administrator.setPassword(new BCryptPasswordEncoder().encode(administrator.getPassword()));
		administratorRepositories.saveAndFlush(administrator);
		
		return toregister(new Administrator());
	}

}
