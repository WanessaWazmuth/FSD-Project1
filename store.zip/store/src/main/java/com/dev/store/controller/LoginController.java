package com.dev.store.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.City;

@Controller
public class LoginController {
	

	@GetMapping("/api/login")
	public ModelAndView register(City cidade) {
		ModelAndView mv =  new ModelAndView("/api/login");
		
		return mv;
	}
	
	

}
