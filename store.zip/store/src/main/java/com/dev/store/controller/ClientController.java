package com.dev.store.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.Client;
import com.dev.store.repositories.CityRepositories;
import com.dev.store.repositories.ClientRepositories;
import com.dev.store.repositories.StateRepositories;

@Controller
public class ClientController {
	
	@Autowired
	private ClientRepositories clientRepositorio;
	
	@Autowired
	private StateRepositories stateRepositories;
	
	@Autowired
	private CityRepositories cityRepositorio;
	
	
	@GetMapping("/api/user/register")
	public ModelAndView register(Client client) {
		ModelAndView mv =  new ModelAndView("api/user/register");
		mv.addObject("client",client);
		mv.addObject("listStates", stateRepositories.findAll());
		mv.addObject("listCity",cityRepositorio.findAll());
		return mv;
	}
	
	@GetMapping("/api/user/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		Optional<Client> client = clientRepositorio.findById(id);
		return register(client.get());
	}
	
	@PostMapping("/api/user/save")
	public ModelAndView save(@Valid Client client, BindingResult result) {
		
		if(result.hasErrors()) {
			return register(client);
		}
		client.setPassword(new BCryptPasswordEncoder().encode(client.getPassword()));
		clientRepositorio.saveAndFlush(client);
		
		return register(new Client());
	}
	
	@GetMapping("/api/user/tolist")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/user/tolist");
		mv.addObject("listClient", clientRepositorio.findAll());
		return mv;
	}

}
