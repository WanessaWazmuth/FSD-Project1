package com.dev.store.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.store.models.InFunds;

public interface InFundsRepositories extends JpaRepository<InFunds, Long> {

}
