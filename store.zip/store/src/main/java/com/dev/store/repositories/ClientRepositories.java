package com.dev.store.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dev.store.models.Client;

public interface ClientRepositories extends JpaRepository<Client, Long> {

	@Query("from Client where email=?1")
	public List<Client> searchClientEmail(String email);
}
