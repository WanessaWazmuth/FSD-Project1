package com.dev.store.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.Role;
import com.dev.store.repositories.RoleRepositories;

@Controller
public class RoleController {
	
	@Autowired
	private RoleRepositories roleRepositories;
	
	
	@GetMapping("/api/admin/role/toregister")
	public ModelAndView toregister(Role role) {
		ModelAndView mv =  new ModelAndView("api/admin/role/register");
		mv.addObject("role",role);
		return mv;
	}
	
	@GetMapping("/api/admin/role/tolist")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/admin/role/list");
		mv.addObject("listRole", roleRepositories.findAll());
		return mv;
	}
	
	@GetMapping("/api/admin/role/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		Optional<Role> role = roleRepositories.findById(id);
		return toregister(role.get());
	}
	
	@GetMapping("/api/admin/role/remove/{id}")
	public ModelAndView remove(@PathVariable("id") Long id) {
		Optional<Role> role = roleRepositories.findById(id);
		roleRepositories.delete(role.get());
		return list();
	}
	
	@PostMapping("/api/admin/role/save")
	public ModelAndView save(@Valid Role role, BindingResult result) {
		
		if(result.hasErrors()) {
			return toregister(role);
		}
		roleRepositories.saveAndFlush(role);
		
		return toregister(new Role());
	}

}
