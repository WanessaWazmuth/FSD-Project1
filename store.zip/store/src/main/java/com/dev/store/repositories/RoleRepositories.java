package com.dev.store.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.store.models.Role;

public interface RoleRepositories extends JpaRepository<Role, Long> {

}
