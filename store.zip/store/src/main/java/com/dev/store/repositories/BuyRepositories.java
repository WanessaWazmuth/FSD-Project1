package com.dev.store.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dev.store.models.Buy;

public interface BuyRepositories extends JpaRepository<Buy, Long> {

}
