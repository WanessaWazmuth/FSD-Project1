package com.dev.store.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.dev.store.models.State;
import com.dev.store.repositories.StateRepositories;

@Controller
public class StateController {
	
	@Autowired
	private StateRepositories stateRepositorio;
	
	
	@GetMapping("/api/admin/states/register")
	public ModelAndView register(State state) {
		ModelAndView mv =  new ModelAndView("api/admin/states/register");
		mv.addObject("state",state);
		return mv;
	}
	
	@GetMapping("/api/admin/states/list")
	public ModelAndView list() {
		ModelAndView mv=new ModelAndView("api/admin/states/list");
		mv.addObject("listStates", stateRepositorio.findAll());
		return mv;
	}
	
	@GetMapping("/api/admin/states/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Long id) {
		Optional<State> state = stateRepositorio.findById(id);
		return register(state.get());
	}
	
	@GetMapping("/api/admin/states/remove/{id}")
	public ModelAndView remove(@PathVariable("id") Long id) {
		Optional<State> state = stateRepositorio.findById(id);
		stateRepositorio.delete(state.get());
		return list();
	}
	
	@PostMapping("/api/admin/states/save")
	public ModelAndView save(@Valid State state, BindingResult result) {
		
		if(result.hasErrors()) {
			return register(state);
		}
		stateRepositorio.saveAndFlush(state);
		
		return register(new State());
	}

}
