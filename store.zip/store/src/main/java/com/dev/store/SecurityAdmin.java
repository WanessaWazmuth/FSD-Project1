package com.dev.store;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
@Order(2)
public class SecurityAdmin extends WebSecurityConfigurerAdapter {

	@Autowired
	private DataSource dataSource;

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {

		auth.jdbcAuthentication().dataSource(dataSource)
				.usersByUsernameQuery(
						"select email as username, password as password, 1 as enable from administrator where email=?")
				.authoritiesByUsernameQuery(
						"select administrator.email as username, role.name as authority from permission inner join administrator on administrator.id=permission.administrator_id inner join role on permission.role_id=role.id where administrator.email=?")
				.passwordEncoder(new BCryptPasswordEncoder());

	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers("/api/login").permitAll().antMatchers("/api/admin/**")
				.hasAnyAuthority("manager").antMatchers("/api/admin/**").authenticated().and().formLogin()
				.loginPage("/api/login").failureUrl("/api/deniedAdministrative").loginProcessingUrl("/api/admin")
				.defaultSuccessUrl("/api/admin").usernameParameter("username").passwordParameter("password").and()
				.logout().logoutRequestMatcher(new AntPathRequestMatcher("/api/admin/logout"))
				.logoutSuccessUrl("/api/login").deleteCookies("JSESSIONID").and().exceptionHandling()
				.accessDeniedPage("/api/deniedAdministrative").and().csrf().disable();

	}

}
